import { create } from "zustand";
import { persist } from "zustand/middleware";

export type Item = string; // id da app ou "folder:<id>"
export interface Folder {
  name: string;
  apps: string[];
}

export interface Settings {
  lang: "pt" | "en";
  theme: "light" | "dark" | "auto";
  wallpaper: string; // chave interna ou data URL
  lockWallpaper: string;
  iconSize: number; // 0.8 .. 1.2
  columns: number; // 4 | 5
  rows: number; // 5 | 6 | 7
  showLabels: boolean;
  showSearchPill: boolean;
  transparency: number; // 0..1 (intensidade do vidro)
  blur: number; // px
  animSpeed: number; // 0.5..1.5 (multiplicador de duração)
  reduceMotion: boolean;
  islandEnabled: boolean;
  islandOffset: number; // px
  islandScale: number;
  islandCharging: boolean;
  lockEnabled: "auto" | "always" | "never";
  lockClock: "thin" | "bold";
  lockCaption: boolean;
  hideAndroidStatusBar: boolean;
  ccShortcuts: string[];
  profileName: string;
  iosIcons: boolean;
  customIcons: Record<string, string>;
  notifPreview: "always" | "unlocked" | "never";
  notifGroup: boolean;
  notifOnLock: boolean;
  demo: boolean;
  folderBlur: boolean;
  dockIcons: number;
  hapticsOn: boolean;
}

export const ALL_CC_SHORTCUTS = [
  "darkmode", "calculator", "battery", "cast", "timer", "alarm", "camera", "flashlight", "hotspot", "location", "nfc", "dataUsage",
];

export const defaultSettings = (native: boolean): Settings => ({
  lang: "pt",
  theme: "auto",
  wallpaper: "home",
  lockWallpaper: "lock",
  iconSize: 1,
  columns: 4,
  rows: 6,
  showLabels: true,
  showSearchPill: true,
  transparency: 0.55,
  blur: 28,
  animSpeed: 1,
  reduceMotion: false,
  islandEnabled: true,
  islandOffset: 0,
  islandScale: 1,
  islandCharging: true,
  lockEnabled: "auto",
  lockClock: "thin",
  lockCaption: true,
  hideAndroidStatusBar: true,
  ccShortcuts: ["darkmode", "calculator", "battery", "cast", "timer", "camera", "alarm", "flashlight"],
  profileName: "",
  iosIcons: true,
  customIcons: {},
  notifPreview: "always",
  notifGroup: true,
  notifOnLock: true,
  demo: !native,
  folderBlur: true,
  dockIcons: 4,
  hapticsOn: true,
});

interface Persisted {
  settings: Settings;
  pages: Item[][];
  dock: Item[];
  folders: Record<string, Folder>;
  knownApps: string[]; // apps já vistas (para detectar novas instalações)
  launchCounts: Record<string, number>;
  initialized: boolean;
}

interface Actions {
  set: (p: Partial<Settings>) => void;
  setLayout: (pages: Item[][], dock: Item[], folders?: Record<string, Folder>) => void;
  patch: (p: Partial<Persisted>) => void;
  countLaunch: (id: string) => void;
  resetLayout: () => void;
}

const isNativeEnv = typeof window !== "undefined" && !!(window as any).IOSBridge;

export const useStore = create<Persisted & Actions>()(
  persist(
    (set) => ({
      settings: defaultSettings(isNativeEnv),
      pages: [],
      dock: [],
      folders: {},
      knownApps: [],
      launchCounts: {},
      initialized: false,
      set: (p) => set((s) => ({ settings: { ...s.settings, ...p } })),
      setLayout: (pages, dock, folders) => set((s) => ({ pages, dock, folders: folders ?? s.folders })),
      patch: (p) => set(p),
      countLaunch: (id) => set((s) => ({ launchCounts: { ...s.launchCounts, [id]: (s.launchCounts[id] || 0) + 1 } })),
      resetLayout: () => set({ initialized: false, pages: [], dock: [], folders: {}, knownApps: [] }),
    }),
    {
      name: "iphone-experience-v1",
      merge: (persisted: any, current) => ({
        ...current,
        ...persisted,
        settings: { ...current.settings, ...(persisted?.settings || {}) },
      }),
    }
  )
);

export function useL() {
  const lang = useStore((s) => s.settings.lang);
  return (pt: string, en: string) => (lang === "en" ? en : pt);
}

export function isFolder(it: Item) {
  return it.startsWith("folder:");
}
