// Ponte entre a UI (React) e o Launcher Android nativo (Kotlin).
// Quando executado no navegador, usa alternativas web ou indica claramente que a função não está disponível.

export interface AppInfo {
  id: string; // "package/activity"
  pkg: string;
  label: string;
  system?: boolean;
}

export interface MediaInfo {
  title: string;
  artist: string;
  album?: string;
  art?: string; // data URL
  playing: boolean;
  position: number; // ms
  duration: number; // ms
  updatedAt: number; // epoch ms
  pkg?: string;
  appLabel?: string;
  demo?: boolean;
}

export interface NotificationInfo {
  key: string;
  pkg: string;
  appLabel: string;
  title: string;
  text: string;
  time: number;
  clearable: boolean;
  demo?: boolean;
}

export interface SystemStatus {
  wifi: boolean;
  wifiConnected: boolean;
  bluetooth: boolean;
  airplane: boolean;
  mobileData: boolean;
  dnd: boolean;
  dndAccess: boolean;
  writeSettings: boolean;
  notifAccess: boolean;
  phonePerm: boolean;
  brightness: number; // 0..1
  autoBrightness: boolean;
  volume: number; // 0..1
  ringer: "normal" | "vibrate" | "silent";
  rotationLock: boolean;
  torch: boolean;
  battery: number; // 0..100
  charging: boolean;
  carrier: string;
  signal: number; // 0..4
  defaultLauncher: boolean;
  deviceSecure: boolean;
  night: boolean;
  imeEnabled: boolean;
}

export interface CallInfo {
  state: "idle" | "ringing" | "offhook";
  since: number;
}

export type Roles = Partial<Record<string, string>>;

interface Bridge {
  getApps(): string;
  getRoles(): string;
  launchApp(id: string, x: number, y: number, w: number, h: number): void;
  appDetails(pkg: string): void;
  uninstall(pkg: string): void;
  getStatus(): string;
  setTorch(on: boolean): void;
  setBrightness(v: number): boolean;
  setVolume(v: number): void;
  setDnd(on: boolean): boolean;
  setRinger(mode: string): boolean;
  setRotationLock(locked: boolean): boolean;
  openPanel(name: string): void;
  openUrl(url: string): void;
  webSearch(q: string): void;
  getMedia(): string;
  mediaAction(action: string, value: number): void;
  getNotifications(): string;
  openNotification(key: string): void;
  dismissNotification(key: string): void;
  clearNotifications(): void;
  getCall(): string;
  requestPermission(name: string): void;
  setImmersive(on: boolean): void;
  vibrate(ms: number): void;
  ready(): void;
}

declare global {
  interface Window {
    IOSBridge?: Bridge;
    __iosNative?: { emit: (type: string, payload: string) => void };
  }
}

export const isNative = typeof window !== "undefined" && !!window.IOSBridge;
const B = () => window.IOSBridge!;

// ---------- eventos nativos ----------
type Listener = (payload: any) => void;
const listeners: Record<string, Set<Listener>> = {};
export function onNative(type: string, fn: Listener) {
  (listeners[type] ||= new Set()).add(fn);
  return () => {
    listeners[type]?.delete(fn);
  };
}
function emit(type: string, payload: any) {
  listeners[type]?.forEach((l) => l(payload));
}
if (typeof window !== "undefined") {
  window.__iosNative = {
    emit: (type, payload) => {
      let p: any = payload;
      try {
        p = typeof payload === "string" ? JSON.parse(payload) : payload;
      } catch {
        /* texto simples */
      }
      emit(type, p);
    },
  };
}

function parse<T>(s: string | null | undefined, fb: T): T {
  if (!s) return fb;
  try {
    return JSON.parse(s) as T;
  } catch {
    return fb;
  }
}

export function iconUrl(id: string) {
  return `https://appassets.androidplatform.net/icons/${encodeURIComponent(id)}.png`;
}

// ---------- apps ----------
export function getApps(): AppInfo[] {
  if (isNative) return parse<AppInfo[]>(B().getApps(), []);
  return [];
}
export function getRoles(): Roles {
  if (isNative) return parse<Roles>(B().getRoles(), {});
  return {};
}
export function launchApp(id: string, rect?: DOMRect) {
  if (!isNative) return false;
  const d = window.devicePixelRatio || 1;
  const r = rect ?? new DOMRect(0, 0, 0, 0);
  B().launchApp(id, Math.round(r.x * d), Math.round(r.y * d), Math.round(r.width * d), Math.round(r.height * d));
  return true;
}
export function appDetails(pkg: string) {
  if (isNative) B().appDetails(pkg);
}
export function uninstall(pkg: string) {
  if (isNative) B().uninstall(pkg);
}

// ---------- estado do sistema ----------
const webStatus: SystemStatus = {
  wifi: typeof navigator !== "undefined" ? navigator.onLine : true,
  wifiConnected: typeof navigator !== "undefined" ? navigator.onLine : true,
  bluetooth: false,
  airplane: false,
  mobileData: false,
  dnd: false,
  dndAccess: false,
  writeSettings: false,
  notifAccess: false,
  phonePerm: false,
  brightness: 0.6,
  autoBrightness: false,
  volume: 0.4,
  ringer: "normal",
  rotationLock: false,
  torch: false,
  battery: 100,
  charging: false,
  carrier: "",
  signal: 4,
  defaultLauncher: false,
  deviceSecure: true,
  night: typeof window !== "undefined" && window.matchMedia?.("(prefers-color-scheme: dark)").matches,
  imeEnabled: false,
};

export function getStatus(): SystemStatus {
  if (isNative) return { ...webStatus, ...parse<Partial<SystemStatus>>(B().getStatus(), {}) };
  return { ...webStatus };
}

// Bateria real no navegador (quando suportada)
export async function initWebBattery(cb: () => void) {
  const nav = navigator as any;
  if (isNative || !nav.getBattery) return;
  try {
    const b = await nav.getBattery();
    const up = () => {
      webStatus.battery = Math.round(b.level * 100);
      webStatus.charging = b.charging;
      cb();
    };
    up();
    b.addEventListener("levelchange", up);
    b.addEventListener("chargingchange", () => {
      up();
      emit("charging", { charging: b.charging, battery: webStatus.battery });
    });
  } catch {
    /* ignorado */
  }
}

// Lanterna: nativa via CameraManager; no navegador via constraint "torch" (Chrome Android)
let webTorchTrack: MediaStreamTrack | null = null;
export async function setTorch(on: boolean): Promise<boolean> {
  if (isNative) {
    B().setTorch(on);
    return true;
  }
  try {
    if (on) {
      const s = await navigator.mediaDevices.getUserMedia({ video: { facingMode: "environment" } });
      webTorchTrack = s.getVideoTracks()[0];
      await webTorchTrack.applyConstraints({ advanced: [{ torch: true } as any] });
      webStatus.torch = true;
    } else {
      webTorchTrack?.stop();
      webTorchTrack = null;
      webStatus.torch = false;
    }
    return true;
  } catch {
    webTorchTrack?.stop();
    webTorchTrack = null;
    webStatus.torch = false;
    return false;
  }
}

export function setBrightness(v: number): boolean {
  if (isNative) return B().setBrightness(v);
  webStatus.brightness = v;
  return false;
}
export function setVolume(v: number) {
  if (isNative) B().setVolume(v);
  else webStatus.volume = v;
}
export function setDnd(on: boolean): boolean {
  if (isNative) return B().setDnd(on);
  return false;
}
export function setRinger(mode: "normal" | "vibrate" | "silent"): boolean {
  if (isNative) return B().setRinger(mode);
  return false;
}
export function setRotationLock(locked: boolean): boolean {
  if (isNative) return B().setRotationLock(locked);
  return false;
}

export type PanelName =
  | "wifi" | "bluetooth" | "internet" | "airplane" | "volume" | "nfc" | "home" | "notifAccess"
  | "policyAccess" | "writeSettings" | "ime" | "imePicker" | "battery" | "cast" | "display" | "sound"
  | "language" | "notifications" | "appSettings" | "settings" | "mobile" | "location" | "camera"
  | "timer" | "alarms" | "calculator" | "dialer" | "hotspot" | "wallpaper" | "dataUsage" | "accessibility";

export function openPanel(name: PanelName) {
  if (isNative) {
    B().openPanel(name);
    return true;
  }
  return false;
}
export function webSearch(q: string) {
  if (isNative) B().webSearch(q);
  else window.open("https://www.google.com/search?q=" + encodeURIComponent(q), "_blank");
}

// ---------- multimédia ----------
export function getMedia(): MediaInfo | null {
  if (isNative) return parse<MediaInfo | null>(B().getMedia(), null);
  return null;
}
export function mediaAction(action: "play" | "pause" | "toggle" | "next" | "prev" | "seek", value = 0) {
  if (isNative) B().mediaAction(action, value);
  else emit("webMediaAction", { action, value });
}

// ---------- notificações ----------
export function getNotifications(): NotificationInfo[] {
  if (isNative) return parse<NotificationInfo[]>(B().getNotifications(), []);
  return [];
}
export function openNotification(key: string) {
  if (isNative) B().openNotification(key);
}
export function dismissNotification(key: string) {
  if (isNative) B().dismissNotification(key);
}
export function clearNotifications() {
  if (isNative) B().clearNotifications();
}

export function getCall(): CallInfo {
  if (isNative) return parse<CallInfo>(B().getCall(), { state: "idle", since: 0 });
  return { state: "idle", since: 0 };
}
export function requestPermission(name: "phone") {
  if (isNative) B().requestPermission(name);
}
export function setImmersive(on: boolean) {
  if (isNative) B().setImmersive(on);
}
export function haptic(ms = 10) {
  if (isNative) B().vibrate(ms);
  else navigator.vibrate?.(ms);
}
export function nativeReady() {
  if (isNative) B().ready();
}
