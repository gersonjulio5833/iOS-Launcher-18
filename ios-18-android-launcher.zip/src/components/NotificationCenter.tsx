import { useMemo, useRef, useState } from "react";
import { useRT } from "@/lib/apps";
import { useStore, useL } from "@/lib/store";
import { wallSrc } from "@/lib/wallpapers";
import * as N from "@/lib/native";
import { IconImage } from "./AppIcon";
import { useClock } from "./StatusBar";
import { Close, Bell } from "./Glyphs";

function ago(t: number, en: boolean) {
  const m = Math.floor((Date.now() - t) / 60000);
  if (m < 1) return en ? "now" : "agora";
  if (m < 60) return en ? `${m}m ago` : `há ${m} min`;
  const h = Math.floor(m / 60);
  if (h < 24) return en ? `${h}h ago` : `há ${h} h`;
  return new Date(t).toLocaleDateString(en ? "en-US" : "pt-PT", { day: "numeric", month: "short" });
}

function NIcon({ pkg, label }: { pkg: string; label: string }) {
  const apps = useRT((s) => s.apps);
  const app = useMemo(() => Object.values(apps).find((a) => a.pkg === pkg), [apps, pkg]);
  if (app) return <IconImage app={app} size={36} />;
  return <IconImage app={{ id: pkg, pkg, label }} size={36} />;
}

function remove(key: string) {
  const rt = useRT.getState();
  rt.set({ notifications: rt.notifications.filter((n) => n.key !== key) });
  N.dismissNotification(key);
}

function Card({ n, dark, hide, stacked, onClick }: { n: N.NotificationInfo; dark: boolean; hide: boolean; stacked?: number; onClick: () => void }) {
  const L = useL();
  const en = useStore((s) => s.settings.lang === "en");
  const ref = useRef<HTMLDivElement>(null);
  const g = useRef<any>({});
  const bg = dark ? "rgba(37,37,40,.66)" : "rgba(246,246,248,.72)";
  const fg = dark ? "#fff" : "#000";
  return (
    <div className="relative" style={{ marginBottom: stacked ? 6 + stacked * 7 : 8 }}>
      {stacked ? [2, 1].slice(2 - Math.min(2, stacked)).map((i) => (
        <div key={i} className="absolute left-0 right-0 rounded-[22px]" style={{ bottom: -i * 7, height: 40, marginInline: i * 10, background: bg, opacity: 0.75 - i * 0.2, backdropFilter: "blur(30px)" }} />
      )) : null}
      <div ref={ref} className="relative rounded-[22px] px-3.5 py-3 flex gap-3 items-start"
        style={{ background: bg, color: fg, backdropFilter: "blur(30px) saturate(180%)", WebkitBackdropFilter: "blur(30px) saturate(180%)", touchAction: "pan-y" }}
        onPointerDown={(e) => { g.current = { x: e.clientX, on: true, moved: false }; }}
        onPointerMove={(e) => {
          if (!g.current.on) return;
          const dx = Math.min(0, e.clientX - g.current.x);
          if (Math.abs(dx) > 8) g.current.moved = true;
          if (ref.current) { ref.current.style.transition = "none"; ref.current.style.transform = `translateX(${dx}px)`; }
        }}
        onPointerUp={(e) => {
          if (!g.current.on) return;
          g.current.on = false;
          const dx = e.clientX - g.current.x;
          if (dx < -120 && n.clearable) {
            if (ref.current) { ref.current.style.transition = "transform .25s"; ref.current.style.transform = "translateX(-110%)"; }
            setTimeout(() => n.demo ? useRT.getState().set({ notifications: useRT.getState().notifications.filter((x) => x.key !== n.key) }) : remove(n.key), 230);
          } else {
            if (ref.current) { ref.current.style.transition = "transform .3s"; ref.current.style.transform = ""; }
            if (!g.current.moved) onClick();
          }
        }}
        onPointerCancel={() => { g.current.on = false; if (ref.current) ref.current.style.transform = ""; }}>
        <NIcon pkg={n.pkg} label={n.appLabel} />
        <div className="flex-1 min-w-0">
          <div className="flex justify-between gap-2">
            <span className="font-semibold text-[15px] truncate">{hide ? n.appLabel : n.title || n.appLabel}</span>
            <span className="text-[13px] shrink-0" style={{ color: dark ? "#ebebf599" : "#3c3c4399" }}>{ago(n.time, en)}</span>
          </div>
          <div className="text-[15px] leading-snug line-clamp-3" style={{ opacity: 0.9 }}>
            {hide ? L("Notificação", "Notification") : n.text}
            {n.demo && <span className="ml-1.5 text-[10px] font-bold text-amber-500">DEMO</span>}
          </div>
          {!!stacked && <div className="text-[13px] mt-0.5" style={{ color: dark ? "#ebebf599" : "#3c3c4399" }}>{L(`Mais ${stacked} notificações`, `${stacked} more notifications`)}</div>}
        </div>
      </div>
    </div>
  );
}

export function NotificationStack({ locked, dark, compact }: { locked: boolean; dark: boolean; compact?: boolean }) {
  const L = useL();
  const list = useRT((s) => s.notifications);
  const s = useStore((x) => x.settings);
  const [open, setOpen] = useState<string | null>(null);
  const hide = s.notifPreview === "never" || (locked && s.notifPreview === "unlocked");
  const groups = useMemo(() => {
    const m = new Map<string, N.NotificationInfo[]>();
    [...list].sort((a, b) => b.time - a.time).forEach((n) => {
      const k = s.notifGroup ? n.pkg : n.key;
      m.set(k, [...(m.get(k) || []), n]);
    });
    return [...m.entries()];
  }, [list, s.notifGroup]);

  const openN = (n: N.NotificationInfo) => {
    if (n.demo) { useRT.getState().set({ toast: L("Notificação de demonstração", "Demo notification") }); return; }
    N.openNotification(n.key);
  };

  if (!groups.length) return compact ? null : (
    <div className="text-center text-white/80 text-[15px] py-10 flex flex-col items-center gap-2"><Bell size={26} />{L("Sem notificações", "No Older Notifications")}</div>
  );
  return (
    <div>
      {groups.slice(0, compact ? 3 : 50).map(([k, items]) => {
        if (items.length > 1 && open !== k) return <Card key={k} n={items[0]} dark={dark} hide={hide} stacked={items.length - 1} onClick={() => setOpen(k)} />;
        return (
          <div key={k}>
            {items.length > 1 && (
              <div className="flex justify-between items-center px-1 mb-2 text-white">
                <span className="text-[20px] font-bold">{items[0].appLabel}</span>
                <div className="flex gap-2">
                  <button className="h-7 px-3 rounded-full text-[13px] font-semibold" style={{ background: "rgba(255,255,255,.25)" }} onClick={() => setOpen(null)}>{L("Mostrar menos", "Show less")}</button>
                  <button className="w-7 h-7 rounded-full flex items-center justify-center" style={{ background: "rgba(255,255,255,.25)" }}
                    onClick={() => items.forEach((n) => (n.demo ? useRT.getState().set({ notifications: useRT.getState().notifications.filter((x) => x.pkg !== n.pkg) }) : remove(n.key)))}><Close size={13} /></button>
                </div>
              </div>
            )}
            {items.map((n) => <Card key={n.key} n={n} dark={dark} hide={hide} onClick={() => openN(n)} />)}
          </div>
        );
      })}
    </div>
  );
}

export default function NotificationCenter({ W, dark, onClose }: { W: number; dark: boolean; onClose: () => void }) {
  const L = useL();
  const s = useStore((x) => x.settings);
  const status = useRT((x) => x.status);
  const list = useRT((x) => x.notifications);
  const now = useClock();
  const ref = useRef<HTMLDivElement>(null);
  const g = useRef<any>({});
  const k = W / 393;
  const date = now.toLocaleDateString(s.lang === "en" ? "en-US" : "pt-PT", { weekday: "long", day: "numeric", month: "long" });

  const close = () => {
    if (ref.current) { ref.current.style.transition = "transform .35s cubic-bezier(.3,.9,.3,1)"; ref.current.style.transform = "translateY(-100%)"; }
    setTimeout(onClose, 300);
  };

  return (
    <div ref={ref} className="absolute inset-0 z-[44] overflow-hidden ios-slide-down" style={{ touchAction: "none" }}
      onPointerDown={(e) => { if (!(e.target as HTMLElement).closest("[data-scroll]")) { g.current = { y: e.clientY, on: true }; (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId); } }}
      onPointerMove={(e) => { if (g.current.on && ref.current) { const dy = Math.min(0, e.clientY - g.current.y); ref.current.style.transition = "none"; ref.current.style.transform = `translateY(${dy}px)`; } }}
      onPointerUp={(e) => { if (!g.current.on) return; g.current.on = false; const dy = e.clientY - g.current.y; if (dy < -60 || Math.abs(dy) < 6) close(); else if (ref.current) { ref.current.style.transition = "transform .3s"; ref.current.style.transform = ""; } }}>
      <img src={wallSrc(s.lockWallpaper, dark)} className="absolute inset-0 w-full h-full object-cover" alt="" draggable={false} />
      <div className="absolute inset-0" style={{ background: "rgba(0,0,0,.18)", backdropFilter: "blur(6px)" }} />
      <div className="absolute inset-x-0 flex flex-col items-center text-[rgba(225,242,255,.9)]" style={{ top: 58 * k }}>
        <div className="font-semibold" style={{ fontSize: 20 * k }}>{date.charAt(0).toUpperCase() + date.slice(1)}</div>
        <div style={{ fontSize: 96 * k, fontWeight: s.lockClock === "thin" ? 200 : 650, lineHeight: 1 }}>{String(now.getHours()).padStart(2, "0")}:{String(now.getMinutes()).padStart(2, "0")}</div>
      </div>
      <div data-scroll className="absolute inset-x-0 overflow-y-auto no-scrollbar" style={{ top: 210 * k, bottom: 30, padding: "0 12px", touchAction: "pan-y" }}>
        <div className="flex justify-between items-center px-1 mb-3 text-white">
          <span className="text-[22px] font-bold">{L("Centro de notificações", "Notification Center")}</span>
          {list.some((n) => n.clearable) && (
            <button className="w-7 h-7 rounded-full flex items-center justify-center" style={{ background: "rgba(255,255,255,.25)" }}
              onClick={() => { N.clearNotifications(); useRT.getState().set({ notifications: useRT.getState().notifications.filter((n) => !n.clearable) }); }}><Close size={13} /></button>
          )}
        </div>
        {N.isNative && !status.notifAccess && (
          <div className="rounded-[22px] p-4 mb-3 text-[15px]" style={{ background: dark ? "rgba(37,37,40,.7)" : "rgba(246,246,248,.78)", color: dark ? "#fff" : "#000", backdropFilter: "blur(30px)" }}>
            <div className="font-semibold mb-1">{L("Permitir acesso às notificações", "Allow notification access")}</div>
            <div className="opacity-80 mb-3">{L("Necessário para mostrar notificações reais, a música actual na Dynamic Island e no Centro de Controlo. Os dados ficam apenas no dispositivo.", "Required to show real notifications and the current media in the Dynamic Island and Control Center. Data stays on device.")}</div>
            <button onClick={() => N.openPanel("notifAccess")} className="h-9 px-4 rounded-full bg-[#0A84FF] text-white font-semibold">{L("Abrir definições", "Open Settings")}</button>
          </div>
        )}
        {!N.isNative && !list.length && <p className="text-white/80 text-center text-sm mb-4">{L("No navegador não há acesso às notificações do Android. Activa «Dados de demonstração» em Ajustes para pré-visualizar.", "Browsers can't read Android notifications. Enable “Demo data” in Settings to preview.")}</p>}
        <NotificationStack locked={false} dark={dark} />
      </div>
      <div className="absolute left-1/2 -translate-x-1/2 rounded-full bg-white" style={{ bottom: 8, width: 134 * k, height: 5 * k }} />
    </div>
  );
}
