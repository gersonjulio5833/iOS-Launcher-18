import type { SVGProps } from "react";

type P = SVGProps<SVGSVGElement> & { size?: number };
const S = ({ size = 24, children, ...p }: P) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="currentColor" {...p}>{children}</svg>
);

export const Airplane = (p: P) => <S {...p}><path d="M21 15.5v-1.8l-8-5V3.6a1.4 1.4 0 0 0-2.8 0v5.1l-8 5v1.8l8-2.4v5.2l-2.2 1.6V21l3.6-1 3.6 1v-1.1L13 18.3v-5.2z" transform="translate(.6 0)" /></S>;
export const Wifi = (p: P) => <S {...p}><path d="M12 18.6a1.9 1.9 0 1 1 0 .01zM5.4 11.9a9.4 9.4 0 0 1 13.2 0l-1.6 1.7a7.1 7.1 0 0 0-10 0zM2 8.5a14.2 14.2 0 0 1 20 0l-1.6 1.6a11.9 11.9 0 0 0-16.8 0zM8.8 15.3a4.6 4.6 0 0 1 6.4 0l-1.6 1.6a2.3 2.3 0 0 0-3.2 0z" /></S>;
export const Bluetooth = (p: P) => <S {...p}><path d="M7 7l10 10-5 4V3l5 4L7 17" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" /></S>;
export const Cellular = (p: P) => <S {...p}><rect x="3" y="15" width="3.2" height="5" rx="1" /><rect x="8" y="11.5" width="3.2" height="8.5" rx="1" /><rect x="13" y="8" width="3.2" height="12" rx="1" /><rect x="18" y="4" width="3.2" height="16" rx="1" /></S>;
export const Antenna = (p: P) => <S {...p}><circle cx="12" cy="10" r="2" /><path d="M12 12v9M7.8 5.8a6 6 0 0 0 0 8.4M16.2 5.8a6 6 0 0 1 0 8.4M5 3a10 10 0 0 0 0 14M19 3a10 10 0 0 1 0 14" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" /></S>;
export const AirDrop = (p: P) => <S {...p}><g fill="none" stroke="currentColor" strokeWidth="1.9" strokeLinecap="round"><path d="M8.2 16.5a5.5 5.5 0 1 1 7.6 0" /><path d="M5.6 19.2a9.3 9.3 0 1 1 12.8 0" /><path d="M10.4 13.6a2.2 2.2 0 1 1 3.2 0" /></g></S>;
export const Link = (p: P) => <S {...p}><g fill="none" stroke="currentColor" strokeWidth="1.9" strokeLinecap="round"><path d="M10 14a4 4 0 0 0 5.6 0l3-3a4 4 0 0 0-5.6-5.6l-1 1" /><path d="M14 10a4 4 0 0 0-5.6 0l-3 3a4 4 0 0 0 5.6 5.6l1-1" /></g></S>;
export const Globe = (p: P) => <S {...p}><g fill="none" stroke="currentColor" strokeWidth="1.7"><circle cx="12" cy="12" r="8.5" /><path d="M3.5 12h17M12 3.5c-3 3.2-3 13.8 0 17M12 3.5c3 3.2 3 13.8 0 17" /></g></S>;
export const Moon = (p: P) => <S {...p}><path d="M20.5 14.6A8.7 8.7 0 0 1 9.4 3.5a8.7 8.7 0 1 0 11.1 11.1z" /></S>;
export const BellSlash = (p: P) => <S {...p}><path d="M18 16.5V11a6 6 0 0 0-4.5-5.8V4.5a1.5 1.5 0 0 0-3 0v.7A6 6 0 0 0 6 11v5.5L4 18.5V19h14.5zM10 20.5a2 2 0 0 0 4 0z" /><path d="M3 3l18 18" stroke="currentColor" strokeWidth="2" strokeLinecap="round" /></S>;
export const Bell = (p: P) => <S {...p}><path d="M18 16.5V11a6 6 0 0 0-4.5-5.8V4.5a1.5 1.5 0 0 0-3 0v.7A6 6 0 0 0 6 11v5.5L4 18.5V19h16v-.5zM10 20.5a2 2 0 0 0 4 0z" /></S>;
export const RotationLock = (p: P) => <S {...p}><g fill="none" stroke="currentColor" strokeWidth="1.9" strokeLinecap="round"><path d="M20 12a8 8 0 1 1-2.4-5.7" /><path d="M18.5 2.5v4h-4" /></g><rect x="8.6" y="11" width="6.8" height="5.4" rx="1.2" /><path d="M10 11V9.6a2 2 0 0 1 4 0V11" fill="none" stroke="currentColor" strokeWidth="1.5" /></S>;
export const Sun = (p: P) => <S {...p}><circle cx="12" cy="12" r="4.2" /><g stroke="currentColor" strokeWidth="2" strokeLinecap="round">{[0, 45, 90, 135, 180, 225, 270, 315].map((a) => <line key={a} x1="12" y1="2.8" x2="12" y2="4.8" transform={`rotate(${a} 12 12)`} />)}</g></S>;
export const Speaker = (p: P) => <S {...p}><path d="M3 9.5h3.5L11.5 5v14l-5-4.5H3z" /><path d="M14.5 9a4 4 0 0 1 0 6M17 6.5a7.5 7.5 0 0 1 0 11" fill="none" stroke="currentColor" strokeWidth="1.9" strokeLinecap="round" /></S>;
export const Contrast = (p: P) => <S {...p}><circle cx="12" cy="12" r="8.5" fill="none" stroke="currentColor" strokeWidth="2.2" /><path d="M12 3.5a8.5 8.5 0 0 1 0 17z" /></S>;
export const Calculator = (p: P) => <S {...p}><rect x="5.5" y="2.5" width="13" height="19" rx="2.5" /><g fill="#000" opacity=".75"><rect x="7.5" y="4.5" width="9" height="3.5" rx=".8" />{[0, 1, 2].map((r) => [0, 1, 2].map((c) => <rect key={`${r}${c}`} x={7.5 + c * 3.3} y={10 + r * 3.6} width="2.3" height="2.4" rx=".6" />))}</g></S>;
export const Battery = (p: P & { level?: number; charging?: boolean }) => {
  const { level = 50, charging, ...rest } = p;
  return <S {...rest} viewBox="0 0 28 14"><rect x=".7" y=".7" width="23.6" height="12.6" rx="3.6" fill="none" stroke="currentColor" strokeOpacity=".45" strokeWidth="1.3" /><rect x="2.4" y="2.4" width={Math.max(1.5, 20.2 * level / 100)} height="9.2" rx="2.1" fill={charging ? "#34C759" : level <= 20 ? "#FF3B30" : "currentColor"} /><path d="M25.8 4.8v4.4a2.3 2.3 0 0 0 0-4.4z" fillOpacity=".45" /></S>;
};
export const Camera = (p: P) => <S {...p}><path d="M9.2 4.5h5.6l1.6 2.2h2.8a2.3 2.3 0 0 1 2.3 2.3v8.7a2.3 2.3 0 0 1-2.3 2.3H4.8a2.3 2.3 0 0 1-2.3-2.3V9a2.3 2.3 0 0 1 2.3-2.3h2.8z" /><circle cx="12" cy="13.2" r="4" fill="#000" fillOpacity=".85" /><circle cx="12" cy="13.2" r="2.7" /><circle cx="18.2" cy="9.4" r=".9" fill="#000" fillOpacity=".6" /></S>;
export const Flashlight = (p: P) => <S {...p}><path d="M7.5 2.5h9v3.2l-2 3.3V21a1.5 1.5 0 0 1-1.5 1.5h-2A1.5 1.5 0 0 1 9.5 21V9L7.5 5.7z" /><circle cx="12" cy="13" r="1.2" fill="#000" fillOpacity=".6" /></S>;
export const Alarm = (p: P) => <S {...p}><g fill="none" stroke="currentColor" strokeWidth="1.9" strokeLinecap="round"><circle cx="12" cy="13" r="7.5" /><path d="M12 9v4.3l2.8 1.8M4 5.5l3-2.5M20 5.5L17 3M7 20l-1.5 1.8M17 20l1.5 1.8" /></g></S>;
export const Timer = (p: P) => <S {...p}><g fill="none" stroke="currentColor" strokeWidth="1.9" strokeLinecap="round"><circle cx="12" cy="13.5" r="7.5" /><path d="M12 13.5l3-3M10 2.5h4M12 2.5V6" /></g></S>;
export const Mirror = (p: P) => <S {...p}><g fill="none" stroke="currentColor" strokeWidth="1.9" strokeLinejoin="round"><rect x="2.5" y="4" width="13" height="10" rx="2" /><rect x="8.5" y="9" width="13" height="10" rx="2" fill="currentColor" fillOpacity=".25" /></g></S>;
export const Hotspot = (p: P) => <S {...p}><g fill="none" stroke="currentColor" strokeWidth="1.9" strokeLinecap="round"><circle cx="12" cy="12" r="2.4" fill="currentColor" /><path d="M7.8 16.2a6 6 0 0 1 0-8.4M16.2 7.8a6 6 0 0 1 0 8.4M5 19a10 10 0 0 1 0-14M19 5a10 10 0 0 1 0 14" /></g></S>;
export const Location = (p: P) => <S {...p}><path d="M20.5 3.5L3.5 11l7.2 2.3 2.3 7.2z" /></S>;
export const Nfc = (p: P) => <S {...p}><g fill="none" stroke="currentColor" strokeWidth="1.9" strokeLinecap="round"><path d="M7 8a6 6 0 0 1 0 8M11 5.5a10 10 0 0 1 0 13M15 3a14 14 0 0 1 0 18" /></g></S>;
export const DataUsage = (p: P) => <S {...p}><path d="M12 3v9l7.8 4.5A9 9 0 1 1 12 3z" opacity=".5" /><path d="M13.5 3.1a9 9 0 0 1 7 12.2l-7-4z" /></S>;
export const Play = (p: P) => <S {...p}><path d="M7 4.5v15a1 1 0 0 0 1.5.86l12.4-7.5a1 1 0 0 0 0-1.72L8.5 3.64A1 1 0 0 0 7 4.5z" /></S>;
export const Pause = (p: P) => <S {...p}><rect x="6" y="4" width="4.2" height="16" rx="1.2" /><rect x="13.8" y="4" width="4.2" height="16" rx="1.2" /></S>;
export const Next = (p: P) => <S {...p}><path d="M2.5 6.2v11.6a.8.8 0 0 0 1.2.7l9.3-5.8V17.8a.8.8 0 0 0 1.2.7l8.9-5.8a.8.8 0 0 0 0-1.4L14.2 5.5a.8.8 0 0 0-1.2.7v5.1L3.7 5.5a.8.8 0 0 0-1.2.7z" /></S>;
export const Prev = (p: P) => <S {...p} style={{ transform: "scaleX(-1)", ...(p.style || {}) }}><path d="M2.5 6.2v11.6a.8.8 0 0 0 1.2.7l9.3-5.8V17.8a.8.8 0 0 0 1.2.7l8.9-5.8a.8.8 0 0 0 0-1.4L14.2 5.5a.8.8 0 0 0-1.2.7v5.1L3.7 5.5a.8.8 0 0 0-1.2.7z" /></S>;
export const AirPlay = (p: P) => <S {...p}><g fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round"><path d="M7.5 17.5a7 7 0 1 1 9 0" /><path d="M9.5 14.6a3.6 3.6 0 1 1 5 0" /></g><path d="M12 15.5l4.5 5.5h-9z" /></S>;
export const Search = (p: P) => <S {...p}><g fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round"><circle cx="10.5" cy="10.5" r="6.5" /><path d="M15.5 15.5l5 5" /></g></S>;
export const Chevron = (p: P) => <S {...p}><path d="M9 5l7 7-7 7" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round" /></S>;
export const Back = (p: P) => <S {...p}><path d="M15 4l-8 8 8 8" fill="none" stroke="currentColor" strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round" /></S>;
export const External = (p: P) => <S {...p}><path d="M14 4h6v6M20 4l-9 9M18 14v5a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V7a1 1 0 0 1 1-1h5" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" /></S>;
export const Plus = (p: P) => <S {...p}><path d="M12 4v16M4 12h16" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" /></S>;
export const Power = (p: P) => <S {...p}><g fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M12 3v8" /><path d="M7 5.8a7.5 7.5 0 1 0 10 0" /></g></S>;
export const Heart = (p: P) => <S {...p}><path d="M12 21s-8.5-5.3-8.5-11.2A4.8 4.8 0 0 1 12 6.6a4.8 4.8 0 0 1 8.5 3.2C20.5 15.7 12 21 12 21z" /></S>;
export const Note = (p: P) => <S {...p}><path d="M9 17.5V6l11-2.5v11.5" fill="none" stroke="currentColor" strokeWidth="2" /><circle cx="6.5" cy="17.5" r="2.7" /><circle cx="17.5" cy="15" r="2.7" /></S>;
export const Home = (p: P) => <S {...p}><path d="M3 11l9-7.5 9 7.5M5.5 9v11h13V9" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinejoin="round" /><rect x="10" y="13.5" width="4" height="6.5" /></S>;
export const Lock = (p: P) => <S {...p}><rect x="5" y="10.5" width="14" height="10.5" rx="2.4" /><path d="M8 10.5V8a4 4 0 0 1 8 0v2.5" fill="none" stroke="currentColor" strokeWidth="2.2" /></S>;
export const PhoneG = (p: P) => <S {...p}><path d="M6.62 10.79c1.44 2.83 3.76 5.14 6.59 6.59l2.2-2.2c.27-.27.67-.36 1.02-.24 1.12.37 2.33.57 3.57.57.55 0 1 .45 1 1V20c0 .55-.45 1-1 1-9.39 0-17-7.61-17-17 0-.55.45-1 1-1h3.5c.55 0 1 .45 1 1 0 1.25.2 2.45.57 3.57.11.35.03.74-.25 1.02l-2.2 2.2z" /></S>;
export const Bolt = (p: P) => <S {...p}><path d="M13.5 2L4 13.5h7L10 22l9.5-11.5h-7z" /></S>;
export const Close = (p: P) => <S {...p}><path d="M6 6l12 12M18 6L6 18" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" /></S>;
export const Minus = (p: P) => <S {...p}><path d="M5 12h14" stroke="currentColor" strokeWidth="3" strokeLinecap="round" /></S>;
export const Keyboard = (p: P) => <S {...p}><rect x="2" y="6" width="20" height="13" rx="2.5" fill="none" stroke="currentColor" strokeWidth="1.8" /><g>{[0, 1, 2, 3, 4].map((i) => <rect key={i} x={5 + i * 3} y="9" width="1.8" height="1.8" rx=".4" />)}{[0, 1, 2, 3].map((i) => <rect key={i} x={6.5 + i * 3} y="12" width="1.8" height="1.8" rx=".4" />)}<rect x="7" y="15" width="10" height="1.8" rx=".6" /></g></S>;
export const Grid = (p: P) => <S {...p}>{[0, 1].map((r) => [0, 1].map((c) => <rect key={`${r}${c}`} x={3.5 + c * 9} y={3.5 + r * 9} width="8" height="8" rx="2.2" />))}</S>;
export const Photo = (p: P) => <S {...p}><rect x="2.5" y="4.5" width="19" height="15" rx="2.5" fill="none" stroke="currentColor" strokeWidth="1.8" /><circle cx="8.5" cy="9.5" r="1.8" /><path d="M3 18l6-6 4 4 3-3 5 5" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinejoin="round" /></S>;
export const Sparkle = (p: P) => <S {...p}><path d="M12 2l2.2 7.8L22 12l-7.8 2.2L12 22l-2.2-7.8L2 12l7.8-2.2z" /></S>;
export const Eye = (p: P) => <S {...p}><path d="M12 5C6.5 5 2.7 9.4 2 12c.7 2.6 4.5 7 10 7s9.3-4.4 10-7c-.7-2.6-4.5-7-10-7z" /><circle cx="12" cy="12" r="3.4" fill="#fff" fillOpacity=".9" /></S>;
export const Text = (p: P) => <S {...p}><path d="M5 5h14M12 5v14" stroke="currentColor" strokeWidth="2.6" strokeLinecap="round" /></S>;
export const Hand = (p: P) => <S {...p}><path d="M8 11V5a1.5 1.5 0 0 1 3 0v5V3.5a1.5 1.5 0 0 1 3 0V10V5a1.5 1.5 0 0 1 3 0v8c0 4-2.5 8-6.5 8C6.5 21 4 17 4 14v-2.5a1.5 1.5 0 0 1 3 0V13" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round" /></S>;
export const Info = (p: P) => <S {...p}><circle cx="12" cy="12" r="9" fill="none" stroke="currentColor" strokeWidth="1.8" /><path d="M12 11v6" stroke="currentColor" strokeWidth="2" strokeLinecap="round" /><circle cx="12" cy="7.6" r="1.2" /></S>;
export const Trash = (p: P) => <S {...p}><path d="M4 6.5h16M9.5 6.5V4.5h5v2M6 6.5l1 13.5h10l1-13.5" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" /></S>;
export const Edit = (p: P) => <S {...p}><path d="M4 20h4L19 9l-4-4L4 16z" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinejoin="round" /></S>;
export const Shield = (p: P) => <S {...p}><path d="M12 2.5l8 3v6c0 5-3.5 8.6-8 10-4.5-1.4-8-5-8-10v-6z" /></S>;
export const Wave = ({ playing = true, color = "#fff", bars = 5, h = 14 }: { playing?: boolean; color?: string; bars?: number; h?: number }) => (
  <div className="flex items-center gap-[2px]" style={{ height: h }}>
    {Array.from({ length: bars }).map((_, i) => (
      <span key={i} className={playing ? "ios-wave" : ""} style={{ width: 2.5, height: playing ? "100%" : "25%", background: color, borderRadius: 2, animationDelay: `${(i * 0.13) % 0.6}s`, transformOrigin: "center" }} />
    ))}
  </div>
);
