import { useEffect, useRef, useState } from "react";
import { useRT } from "@/lib/apps";
import { useStore, useL } from "@/lib/store";
import * as N from "@/lib/native";
import { Next, Pause, Play, Prev, AirPlay, PhoneG, Wave, Lock, Battery } from "./Glyphs";

export function fmtMs(ms: number) {
  const s = Math.max(0, Math.floor(ms / 1000));
  return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, "0")}`;
}

export function livePos(m: N.MediaInfo | null) {
  if (!m) return 0;
  const p = m.playing ? m.position + (Date.now() - m.updatedAt) : m.position;
  return m.duration ? Math.min(p, m.duration) : p;
}

export function MediaArt({ m, size, radius }: { m: N.MediaInfo; size: number; radius: number }) {
  return m.art ? (
    <img src={m.art} alt="" className="object-cover shrink-0" style={{ width: size, height: size, borderRadius: radius }} />
  ) : (
    <div className="shrink-0 flex items-center justify-center" style={{ width: size, height: size, borderRadius: radius, background: "linear-gradient(135deg,#FD5E78,#8A2BD4)" }}>
      <svg viewBox="0 0 24 24" width={size * 0.5} height={size * 0.5} fill="#fff"><path d="M9 17.5V6l11-2.5v11.5" fill="none" stroke="#fff" strokeWidth="2" /><circle cx="6.5" cy="17.5" r="2.7" /><circle cx="17.5" cy="15" r="2.7" /></svg>
    </div>
  );
}

export default function DynamicIsland({ W, locked }: { W: number; locked: boolean }) {
  const L = useL();
  const s = useStore((x) => x.settings);
  const media = useRT((x) => x.media);
  const call = useRT((x) => x.call);
  const status = useRT((x) => x.status);
  const [expanded, setExpanded] = useState(false);
  const [charging, setCharging] = useState(false);
  const [, force] = useState(0);
  const lp = useRef<any>(null);
  const prevCharging = useRef(status.charging);

  // Indicador de carregamento (evento real da bateria)
  useEffect(() => {
    if (status.charging && !prevCharging.current && s.islandCharging) {
      setCharging(true);
      const t = setTimeout(() => setCharging(false), 2800);
      prevCharging.current = status.charging;
      return () => clearTimeout(t);
    }
    prevCharging.current = status.charging;
  }, [status.charging, s.islandCharging]);

  // Actualização do progresso apenas quando expandido ou em chamada (poupa bateria)
  useEffect(() => {
    if (!(expanded && media?.playing) && call.state !== "offhook") return;
    const t = setInterval(() => force((n) => n + 1), 1000);
    return () => clearInterval(t);
  }, [expanded, media?.playing, call.state]);

  useEffect(() => N.onNative("home", () => setExpanded(false)), []);
  useEffect(() => { if (!media) setExpanded(false); }, [media]);
  const overlay = useRT((x) => x.overlay);
  useEffect(() => setExpanded(false), [locked, overlay]);

  if (!s.islandEnabled) return null;

  const k = (W / 393) * s.islandScale;
  const baseW = 124 * k, baseH = 36.5 * k;
  const inCall = call.state !== "idle";
  const hasMedia = !!media;
  let mode: "idle" | "compact" | "expanded" | "charging" | "lock" = "idle";
  if (charging) mode = "charging";
  else if (expanded && hasMedia) mode = "expanded";
  else if (inCall || hasMedia) mode = "compact";
  else if (locked) mode = "lock";

  const dims = {
    idle: [baseW, baseH, baseH / 2],
    lock: [baseW + 14 * k, baseH, baseH / 2],
    compact: [Math.min(W - 40, 228 * k), baseH, baseH / 2],
    charging: [Math.min(W - 40, 250 * k), baseH, baseH / 2],
    expanded: [W - 20, 190 * k, 46 * k],
  }[mode];

  const onDown = () => {
    lp.current = setTimeout(() => { if (hasMedia) { setExpanded(true); N.haptic(12); } }, 420);
  };
  const onUp = () => clearTimeout(lp.current);
  const onClick = () => {
    if (mode === "compact") {
      if (inCall) N.openPanel("dialer");
      else setExpanded(true);
    }
  };
  const pos = livePos(media);
  const elapsed = inCall && call.since ? Date.now() - call.since : 0;
  const spring = s.reduceMotion ? "none" : `width ${0.5 * s.animSpeed}s cubic-bezier(.3,1.35,.45,1), height ${0.5 * s.animSpeed}s cubic-bezier(.3,1.3,.45,1), border-radius ${0.45 * s.animSpeed}s ease`;

  return (
    <>
      {expanded && <div className="absolute inset-0 z-[48]" onPointerDown={() => setExpanded(false)} />}
      <div className="absolute left-1/2 z-[49] bg-black text-white overflow-hidden select-none"
        onPointerDown={onDown} onPointerUp={onUp} onPointerCancel={onUp} onClick={onClick}
        style={{ top: 11 * k + s.islandOffset, width: dims[0], height: dims[1], borderRadius: dims[2], transform: "translateX(-50%)", transition: spring,
          boxShadow: mode === "expanded" ? "0 12px 40px rgba(0,0,0,.35)" : undefined }}>
        {/* Bloqueio */}
        {mode === "lock" && <div className="absolute inset-y-0 left-3.5 flex items-center ios-fade-in"><Lock size={13 * k} /></div>}

        {/* Carregamento */}
        {mode === "charging" && (
          <div className="absolute inset-0 flex items-center justify-between px-4 ios-fade-in" style={{ fontSize: 13 * k }}>
            <span className="font-semibold">{L("A carregar", "Charging")}</span>
            <span className="flex items-center gap-1.5 text-[#34C759] font-semibold">{status.battery}% <Battery size={26 * k} level={status.battery} charging /></span>
          </div>
        )}

        {/* Compacto */}
        {mode === "compact" && (
          <div className="absolute inset-0 flex items-center justify-between ios-fade-in" style={{ padding: `0 ${10 * k}px 0 ${inCall ? 14 * k : 7 * k}px` }}>
            {inCall ? (
              <>
                <span className="flex items-center gap-1.5 text-[#34C759] font-semibold" style={{ fontSize: 14 * k }}>
                  <PhoneG size={15 * k} /> {call.state === "ringing" ? L("Chamada", "Call") : fmtMs(elapsed)}
                </span>
                <Wave color="#34C759" bars={7} h={14 * k} />
              </>
            ) : media && (
              <>
                <MediaArt m={media} size={24 * k} radius={7 * k} />
                {media.demo && <span className="text-[9px] font-bold text-amber-400 tracking-wider">DEMO</span>}
                <Wave playing={media.playing} color="#FF6B9A" bars={5} h={13 * k} />
              </>
            )}
          </div>
        )}

        {/* Expandido */}
        {mode === "expanded" && media && (
          <div className="absolute inset-0 ios-fade-in-slow" style={{ padding: `${22 * k}px ${24 * k}px` }} onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center gap-3.5">
              <MediaArt m={media} size={58 * k} radius={13 * k} />
              <div className="flex-1 min-w-0">
                <div className="font-semibold truncate" style={{ fontSize: 17 * k }}>{media.title || L("Sem título", "Not Playing")}</div>
                <div className="truncate text-white/55" style={{ fontSize: 15.5 * k }}>{media.artist || media.appLabel}</div>
              </div>
              <div className="self-start pt-1 flex flex-col items-end gap-1">
                <Wave playing={media.playing} color="#C77DFF" bars={6} h={16 * k} />
                {media.demo && <span className="text-[9px] font-bold text-amber-400 tracking-wider">DEMO</span>}
              </div>
            </div>
            <div className="flex items-center gap-3 mt-4 text-white/55" style={{ fontSize: 12.5 * k }}>
              <span className="w-9 tabular-nums">{fmtMs(pos)}</span>
              <div className="flex-1 h-[6px] rounded-full bg-white/25 overflow-hidden relative"
                onPointerDown={(e) => { const r = e.currentTarget.getBoundingClientRect(); if (media.duration) N.mediaAction("seek", ((e.clientX - r.left) / r.width) * media.duration); }}>
                <div className="absolute inset-y-0 left-0 bg-white rounded-full" style={{ width: `${media.duration ? (pos / media.duration) * 100 : 0}%` }} />
              </div>
              <span className="w-10 text-right tabular-nums">-{fmtMs(Math.max(0, media.duration - pos))}</span>
            </div>
            <div className="flex items-center justify-between mt-3 px-[12%] relative">
              <button onClick={() => N.mediaAction("prev")} className="active:scale-90 transition-transform"><Prev size={30 * k} /></button>
              <button onClick={() => N.mediaAction("toggle")} className="active:scale-90 transition-transform">{media.playing ? <Pause size={36 * k} /> : <Play size={36 * k} />}</button>
              <button onClick={() => N.mediaAction("next")} className="active:scale-90 transition-transform"><Next size={30 * k} /></button>
              <button onClick={() => N.openPanel("volume")} className="absolute right-0 text-white/90"><AirPlay size={24 * k} /></button>
            </div>
          </div>
        )}
      </div>
    </>
  );
}
