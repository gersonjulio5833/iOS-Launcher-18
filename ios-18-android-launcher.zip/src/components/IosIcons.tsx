import { useEffect, useState, type ReactElement } from "react";

// Ícones inspirados no iOS 18 desenhados em SVG (viewBox 100x100). A máscara squircle é aplicada pelo AppIcon.

const PHONE =
  "M6.62 10.79c1.44 2.83 3.76 5.14 6.59 6.59l2.2-2.2c.27-.27.67-.36 1.02-.24 1.12.37 2.33.57 3.57.57.55 0 1 .45 1 1V20c0 .55-.45 1-1 1-9.39 0-17-7.61-17-17 0-.55.45-1 1-1h3.5c.55 0 1 .45 1 1 0 1.25.2 2.45.57 3.57.11.35.03.74-.25 1.02l-2.2 2.2z";

function gearPath(cx: number, cy: number, rOut: number, rIn: number, teeth: number) {
  let d = "";
  const step = (Math.PI * 2) / teeth;
  for (let i = 0; i < teeth; i++) {
    const a = i * step;
    const pts = [
      [a - step * 0.2, rIn],
      [a - step * 0.12, rOut],
      [a + step * 0.12, rOut],
      [a + step * 0.2, rIn],
      [a + step * 0.5, rIn],
    ];
    pts.forEach(([ang, r], j) => {
      const x = cx + Math.cos(ang) * r;
      const y = cy + Math.sin(ang) * r;
      d += (i === 0 && j === 0 ? "M" : "L") + x.toFixed(2) + " " + y.toFixed(2);
    });
  }
  return d + "Z";
}

const G = ({ id, a, b, x2 = "0", y2 = "1" }: { id: string; a: string; b: string; x2?: string; y2?: string }) => (
  <defs>
    <linearGradient id={id} x1="0" y1="0" x2={x2} y2={y2}>
      <stop offset="0" stopColor={a} />
      <stop offset="1" stopColor={b} />
    </linearGradient>
  </defs>
);

function useNow(intervalMs: number) {
  const [now, setNow] = useState(() => new Date());
  useEffect(() => {
    const t = setInterval(() => setNow(new Date()), intervalMs);
    return () => clearInterval(t);
  }, [intervalMs]);
  return now;
}

function CalendarIcon({ lang }: { lang: string }) {
  const now = useNow(60000);
  const day = now.toLocaleDateString(lang === "en" ? "en-US" : "pt-PT", { weekday: "short" }).replace(".", "").toUpperCase().slice(0, 3);
  return (
    <svg viewBox="0 0 100 100">
      <rect width="100" height="100" fill="#fff" />
      <text x="50" y="27" textAnchor="middle" fontSize="17" fontWeight="600" fill="#FF3B30" fontFamily="-apple-system,Inter,Roboto,sans-serif">{day}</text>
      <text x="50" y="80" textAnchor="middle" fontSize="54" fontWeight="300" fill="#1c1c1e" fontFamily="-apple-system,Inter,Roboto,sans-serif">{now.getDate()}</text>
    </svg>
  );
}

function ClockIcon() {
  const now = useNow(30000);
  const h = (now.getHours() % 12) * 30 + now.getMinutes() * 0.5;
  const m = now.getMinutes() * 6;
  return (
    <svg viewBox="0 0 100 100">
      <rect width="100" height="100" fill="#000" />
      <circle cx="50" cy="50" r="40" fill="#fff" />
      {Array.from({ length: 12 }).map((_, i) => (
        <text key={i} x={50 + Math.sin((i + 1) * Math.PI / 6) * 31} y={50 - Math.cos((i + 1) * Math.PI / 6) * 31 + 4} fontSize="10" textAnchor="middle" fill="#000" fontFamily="Inter,Roboto,sans-serif">{i + 1}</text>
      ))}
      <line x1="50" y1="50" x2="50" y2="28" stroke="#000" strokeWidth="4" strokeLinecap="round" transform={`rotate(${h} 50 50)`} />
      <line x1="50" y1="50" x2="50" y2="17" stroke="#000" strokeWidth="3" strokeLinecap="round" transform={`rotate(${m} 50 50)`} />
      <line x1="50" y1="58" x2="50" y2="15" stroke="#FF9500" strokeWidth="1.5" transform={`rotate(${now.getSeconds() * 6} 50 50)`} />
      <circle cx="50" cy="50" r="3" fill="#FF9500" />
    </svg>
  );
}

const ICONS: Record<string, (lang: string) => ReactElement> = {
  facetime: () => (
    <svg viewBox="0 0 100 100"><G id="ft" a="#5DF777" b="#0ABD31" /><rect width="100" height="100" fill="url(#ft)" />
      <rect x="18" y="33" width="44" height="34" rx="9" fill="#fff" /><path d="M64 46 L82 34 V66 L64 54Z" fill="#fff" strokeLinejoin="round" stroke="#fff" strokeWidth="3" /></svg>
  ),
  calendar: (lang) => <CalendarIcon lang={lang} />,
  photos: () => (
    <svg viewBox="0 0 100 100"><rect width="100" height="100" fill="#fff" />
      {["#FBB531", "#F6851F", "#EF4C3F", "#C44B9A", "#8A58C6", "#3F8FE8", "#3DBB8E", "#B5D334"].map((c, i) => (
        <ellipse key={i} cx="50" cy="31" rx="10.5" ry="17" fill={c} opacity="0.86" transform={`rotate(${i * 45} 50 50)`} style={{ mixBlendMode: "multiply" }} />
      ))}</svg>
  ),
  camera: () => (
    <svg viewBox="0 0 100 100"><G id="cam" a="#F2F2F4" b="#A6A8AE" /><rect width="100" height="100" fill="url(#cam)" />
      <rect x="14" y="31" width="72" height="46" rx="9" fill="#1d1d1f" /><rect x="36" y="25" width="22" height="10" rx="3" fill="#1d1d1f" />
      <circle cx="50" cy="54" r="15" fill="#e9e9ec" /><circle cx="50" cy="54" r="11" fill="#1d1d1f" /><circle cx="50" cy="54" r="5" fill="#3a3d48" /><circle cx="74" cy="40" r="3" fill="#f5c400" /></svg>
  ),
  mail: () => (
    <svg viewBox="0 0 100 100"><G id="ml" a="#1FB4FF" b="#1366F2" /><rect width="100" height="100" fill="url(#ml)" />
      <rect x="15" y="27" width="70" height="48" rx="6" fill="#fff" /><path d="M17 30 L50 56 L83 30" fill="none" stroke="#3b8af5" strokeWidth="3" /><path d="M17 72 L42 50 M83 72 L58 50" stroke="#c8dcfa" strokeWidth="2" /></svg>
  ),
  notes: () => (
    <svg viewBox="0 0 100 100"><rect width="100" height="100" fill="#fff" /><G id="nt" a="#FFDE5A" b="#F9C80E" /><rect width="100" height="27" fill="url(#nt)" />
      <line x1="0" y1="27" x2="100" y2="27" stroke="#d9b20a" strokeWidth="1" />
      {[45, 62, 79].map((y) => <line key={y} x1="0" y1={y} x2="100" y2={y} stroke="#d6d6da" strokeWidth="1.6" />)}
      <g fill="#bdbdc2">{[10, 22, 34, 46, 58, 70, 82, 94].map((x) => <circle key={x} cx={x} cy="13" r="1.2" opacity=".5" />)}</g></svg>
  ),
  reminders: () => (
    <svg viewBox="0 0 100 100"><rect width="100" height="100" fill="#fff" />
      {[["#0A84FF", 28], ["#FF3B30", 50], ["#FF9500", 72]].map(([c, y]) => (
        <g key={String(y)}><circle cx="24" cy={y as number} r="7" fill="none" stroke="#fff" strokeWidth="2" /><circle cx="24" cy={y as number} r="6.5" fill={c as string} /><circle cx="24" cy={y as number} r="3.2" fill="#fff" opacity=".0" />
          <line x1="38" y1={y as number} x2="86" y2={y as number} stroke="#d1d1d6" strokeWidth="2" /></g>
      ))}</svg>
  ),
  clock: () => <ClockIcon />,
  news: () => (
    <svg viewBox="0 0 100 100"><rect width="100" height="100" fill="#fff" />
      <path d="M22 22 h18 l38 38 v18 h-18 l-38 -38z" fill="#FA2D48" /><path d="M22 44 v34 h34z M78 56 v-34 h-34z" fill="#FA2D48" opacity=".85" />
      <path d="M22 22 h18 l38 38 v18 h-18 l-38 -38z" fill="#fff" opacity=".0" /></svg>
  ),
  tv: () => (
    <svg viewBox="0 0 100 100"><rect width="100" height="100" fill="#0b0b0c" />
      <path d="M22 38 L40 50 L22 62Z" fill="#fff" /><text x="47" y="62" fontSize="30" fontWeight="700" fill="#fff" fontFamily="-apple-system,Inter,Roboto,sans-serif">tv</text></svg>
  ),
  podcasts: () => (
    <svg viewBox="0 0 100 100"><G id="pd" a="#F15AFF" b="#8A2BD4" /><rect width="100" height="100" fill="url(#pd)" />
      <circle cx="50" cy="44" r="27" fill="none" stroke="#fff" strokeWidth="6" strokeDasharray="120 50" strokeDashoffset="-48" strokeLinecap="round" />
      <circle cx="50" cy="44" r="16" fill="none" stroke="#fff" strokeWidth="5.5" strokeDasharray="70 31" strokeDashoffset="-28" strokeLinecap="round" />
      <circle cx="50" cy="43" r="7" fill="#fff" /><rect x="45" y="54" width="10" height="26" rx="5" fill="#fff" /></svg>
  ),
  appstore: () => (
    <svg viewBox="0 0 100 100"><G id="as" a="#1AC3FC" b="#1D6EF2" /><rect width="100" height="100" fill="url(#as)" />
      <g stroke="#fff" strokeWidth="7" strokeLinecap="round"><line x1="56" y1="24" x2="32" y2="66" /><line x1="44" y1="24" x2="68" y2="66" /><line x1="24" y1="56" x2="76" y2="56" /><line x1="28" y1="72" x2="24" y2="78" /></g></svg>
  ),
  maps: () => (
    <svg viewBox="0 0 100 100"><rect width="100" height="100" fill="#E9F3E3" />
      <path d="M0 64 L100 26 V44 L0 82Z" fill="#F9D869" /><path d="M58 0 L74 0 L40 100 L24 100Z" fill="#fff" /><path d="M0 0 H40 L0 40Z" fill="#9ED796" /><path d="M100 100 H62 L100 64Z" fill="#F69BB6" />
      <circle cx="42" cy="62" r="15" fill="#fff" /><circle cx="42" cy="62" r="12" fill="#1A83F7" /><path d="M42 53 L49 69 L42 65 L35 69Z" fill="#fff" /></svg>
  ),
  health: () => (
    <svg viewBox="0 0 100 100"><rect width="100" height="100" fill="#fff" /><G id="hl" a="#FF6482" b="#FF2D55" />
      <path d="M68 22c9 0 16 7 16 17 0 18-24 29-34 38C40 68 16 57 16 39c0-10 7-17 16-17 8 0 13 5 18 11 5-6 10-11 18-11z" fill="url(#hl)" transform="translate(50 50) scale(.68) translate(-50 -50)" /></svg>
  ),
  wallet: () => (
    <svg viewBox="0 0 100 100"><rect width="100" height="100" fill="#141416" />
      <rect x="18" y="24" width="64" height="50" rx="7" fill="#2b2b2e" />
      {["#45B8F0", "#FBC02D", "#EE5144", "#4CD964"].map((c, i) => <rect key={c} x="22" y={28 + i * 7} width="56" height="14" rx="3" fill={c} />)}
      <path d="M18 54 h22 a10 10 0 0 0 20 0 h22 v14 a7 7 0 0 1 -7 7 h-50 a7 7 0 0 1 -7 -7z" fill="#3a3a3d" /></svg>
  ),
  settings: () => (
    <svg viewBox="0 0 100 100"><G id="st" a="#E2E2E6" b="#8E8E93" /><rect width="100" height="100" fill="url(#st)" />
      <circle cx="50" cy="50" r="38" fill="#47474b" /><path d={gearPath(50, 50, 36, 29, 36)} fill="#cfd0d4" /><circle cx="50" cy="50" r="25" fill="#5d5e63" />
      <path d={gearPath(50, 50, 22, 16, 8)} fill="#d6d7db" /><circle cx="50" cy="50" r="8" fill="#5d5e63" /><circle cx="50" cy="50" r="4.5" fill="#cfd0d4" /></svg>
  ),
  phone: () => (
    <svg viewBox="0 0 100 100"><G id="ph" a="#5DF777" b="#0ABD31" /><rect width="100" height="100" fill="url(#ph)" />
      <path d={PHONE} fill="#fff" transform="translate(21 21) scale(2.4)" /></svg>
  ),
  safari: () => (
    <svg viewBox="0 0 100 100"><rect width="100" height="100" fill="#fff" /><G id="sf" a="#19D7FF" b="#1E64F0" />
      <circle cx="50" cy="50" r="38" fill="url(#sf)" />
      {Array.from({ length: 48 }).map((_, i) => (
        <line key={i} x1="50" y1="15" x2="50" y2={i % 4 === 0 ? 20 : 18} stroke="#fff" strokeWidth=".9" transform={`rotate(${i * 7.5} 50 50)`} />
      ))}
      <g transform="rotate(45 50 50)"><path d="M50 22 L56 50 L44 50Z" fill="#FF3B30" /><path d="M50 78 L56 50 L44 50Z" fill="#fff" /></g></svg>
  ),
  messages: () => (
    <svg viewBox="0 0 100 100"><G id="ms" a="#5DF777" b="#0ABD31" /><rect width="100" height="100" fill="url(#ms)" />
      <ellipse cx="50" cy="47" rx="33" ry="27" fill="#fff" /><path d="M26 64 C26 72 20 77 16 79 C27 80 34 76 38 71Z" fill="#fff" /></svg>
  ),
  music: () => (
    <svg viewBox="0 0 100 100"><G id="mu" a="#FD5E78" b="#FA233B" /><rect width="100" height="100" fill="url(#mu)" />
      <path d="M41 28 L72 21 V62" fill="none" stroke="#fff" strokeWidth="6" strokeLinejoin="round" /><line x1="41" y1="28" x2="41" y2="70" stroke="#fff" strokeWidth="6" />
      <ellipse cx="33" cy="70" rx="10" ry="8" fill="#fff" /><ellipse cx="64" cy="62" rx="10" ry="8" fill="#fff" /></svg>
  ),
  calculator: () => (
    <svg viewBox="0 0 100 100"><rect width="100" height="100" fill="#1c1c1e" />
      {[0, 1, 2, 3].map((r) => [0, 1, 2, 3].map((c) => (
        <circle key={`${r}${c}`} cx={23 + c * 18} cy={26 + r * 17} r="7" fill={c === 3 ? "#FF9F0A" : r === 0 ? "#a5a5a5" : "#505050"} />
      )))}</svg>
  ),
  contacts: () => (
    <svg viewBox="0 0 100 100"><G id="ct" a="#DADADF" b="#A5A5AB" /><rect width="100" height="100" fill="url(#ct)" />
      <circle cx="50" cy="40" r="16" fill="#fff" /><path d="M22 82 C24 62 38 58 50 58 C62 58 76 62 78 82Z" fill="#fff" /></svg>
  ),
  files: () => (
    <svg viewBox="0 0 100 100"><rect width="100" height="100" fill="#fff" /><G id="fl" a="#5BC0FF" b="#1A7EF4" />
      <path d="M16 30 a5 5 0 0 1 5-5 h20 l7 7 h31 a5 5 0 0 1 5 5 v36 a5 5 0 0 1 -5 5 h-58 a5 5 0 0 1 -5 -5z" fill="url(#fl)" /></svg>
  ),
  weather: () => (
    <svg viewBox="0 0 100 100"><G id="wt" a="#2E9BF0" b="#1667C9" /><rect width="100" height="100" fill="url(#wt)" />
      <circle cx="38" cy="38" r="15" fill="#FFD60A" /><path d="M34 74 a14 14 0 0 1 4-27 a18 18 0 0 1 34 4 a12 12 0 0 1 2 23z" fill="#fff" /></svg>
  ),
  flashlight: () => (
    <svg viewBox="0 0 100 100"><G id="fs" a="#FFD84D" b="#FF9F0A" /><rect width="100" height="100" fill="url(#fs)" />
      <g transform="rotate(35 50 50)"><rect x="40" y="38" width="20" height="44" rx="4" fill="#fff" /><path d="M34 20 h32 l-6 18 h-20z" fill="#fff" /><circle cx="50" cy="52" r="3.5" fill="#FF9F0A" /></g></svg>
  ),
  translate: () => (
    <svg viewBox="0 0 100 100"><rect width="100" height="100" fill="#0b0b0c" /><rect x="16" y="20" width="40" height="40" rx="8" fill="#1A83F7" /><rect x="44" y="40" width="40" height="40" rx="8" fill="#fff" />
      <text x="36" y="50" fontSize="24" textAnchor="middle" fill="#fff" fontWeight="700">A</text><text x="64" y="70" fontSize="22" textAnchor="middle" fill="#000" fontWeight="700">文</text></svg>
  ),
  voice: () => (
    <svg viewBox="0 0 100 100"><rect width="100" height="100" fill="#0b0b0c" />
      {[10, 22, 34, 46, 30, 18, 40, 26, 14].map((h, i) => <rect key={i} x={18 + i * 7.5} y={50 - h / 2} width="4" height={h} rx="2" fill="#FF3B30" />)}</svg>
  ),
  launcher: () => ICONS.settings("pt"),
};

export const IOS_ICON_KEYS = Object.keys(ICONS).filter((k) => k !== "launcher");

export function IosIcon({ name, lang = "pt" }: { name: string; lang?: string }) {
  const f = ICONS[name];
  return f ? f(lang) : null;
}

export function hasIosIcon(name: string) {
  return !!ICONS[name];
}

// Ícone genérico para apps sem ícone (modo navegador)
export function LetterIcon({ label }: { label: string }) {
  const hues = [210, 140, 20, 280, 340, 45, 190];
  const h = hues[(label.charCodeAt(0) || 0) % hues.length];
  return (
    <svg viewBox="0 0 100 100"><defs><linearGradient id={`lt${h}`} x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor={`hsl(${h} 80% 62%)`} /><stop offset="1" stopColor={`hsl(${h} 75% 45%)`} /></linearGradient></defs>
      <rect width="100" height="100" fill={`url(#lt${h})`} /><text x="50" y="66" textAnchor="middle" fontSize="46" fontWeight="600" fill="#fff" fontFamily="-apple-system,Inter,Roboto,sans-serif">{label.slice(0, 1).toUpperCase()}</text></svg>
  );
}
