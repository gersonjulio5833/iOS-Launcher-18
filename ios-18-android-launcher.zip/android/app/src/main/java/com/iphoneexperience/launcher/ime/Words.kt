package com.iphoneexperience.launcher.ime

/** Pequeno dicionário de português para sugestões (offline). */
object Words {
    val PT = listOf(
        "a", "abraço", "agora", "ainda", "algo", "alguém", "ali", "amanhã", "amiga", "amigo", "amor", "ano",
        "anos", "antes", "ao", "aos", "aquela", "aquelas", "aquele", "aqueles", "aqui", "aquilo", "as",
        "até", "beijo", "beijos", "bem", "boa", "bom", "Brasil", "cada", "casa", "certeza", "certo", "claro",
        "coisa", "coisas", "com", "como", "cá", "da", "das", "de", "dela", "delas", "dele", "deles",
        "depois", "desculpa", "dia", "do", "dos", "e", "ela", "elas", "ele", "eles", "em", "entre", "então",
        "era", "essa", "essas", "esse", "esses", "esta", "estamos", "estas", "estava", "estavam", "este",
        "estes", "esteve", "estive", "estivemos", "estiveram", "estou", "está", "estávamos", "estão", "eu",
        "falamos", "falar", "família", "favor", "fazer", "feito", "fixe", "foi", "foram", "fosse", "grande",
        "havia", "hoje", "hora", "horas", "ir", "isso", "isto", "já", "lhe", "lhes", "ligar", "ligo",
        "Lisboa", "lá", "mais", "mal", "mas", "me", "melhor", "mensagem", "mesmo", "meu", "meus", "minha",
        "minhas", "minuto", "minutos", "muito", "mês", "nada", "nas", "nem", "ninguém", "noite", "nos",
        "nossa", "nossas", "nosso", "nossos", "nova", "novo", "num", "numa", "nunca", "não", "nós", "o",
        "obrigada", "obrigado", "obrigadíssimo", "olá", "onde", "ontem", "os", "ou", "outra", "outras",
        "outro", "outros", "para", "pela", "pelas", "pelo", "pelos", "pequeno", "pessoa", "pessoas", "pior",
        "por", "porque", "Porto", "Portugal", "português", "possível", "primeiro", "qual", "quando",
        "quanto", "quantos", "que", "quem", "quê", "saudade", "se", "seja", "sem", "semana", "sempre", "ser",
        "será", "seu", "seus", "sim", "sua", "suas", "só", "talvez", "também", "tarde", "te", "telefone",
        "tem", "tempo", "tenho", "ter", "teu", "teus", "tinha", "trabalho", "tu", "tua", "tuas", "tudo",
        "têm", "um", "uma", "vai", "vamos", "vejo", "vem", "venho", "ver", "vi", "vida", "você", "vocês",
        "vos", "vou", "à", "ótimo", "última", "último"
    )
}
