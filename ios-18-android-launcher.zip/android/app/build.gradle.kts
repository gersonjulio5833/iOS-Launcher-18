plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.iphoneexperience.launcher"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.iphoneexperience.launcher"
        minSdk = 26
        targetSdk = 33
        versionCode = 1
        versionName = "1.0.0"
    }

    signingConfigs {
        // Chave de depuração incluída no projecto para que todas as compilações (nuvem ou local)
        // tenham a mesma assinatura e possam ser actualizadas por cima sem desinstalar.
        getByName("debug") {
            storeFile = file("debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
    }

    buildTypes {
        getByName("debug") { signingConfig = signingConfigs.getByName("debug") }
        getByName("release") {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("debug")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

// Copia a interface web compilada (../dist/index.html) para os assets antes de compilar.
val copyWebUi by tasks.registering(Copy::class) {
    from(rootProject.file("../dist")) { include("index.html") }
    into(file("src/main/assets/www"))
}
tasks.named("preBuild") { dependsOn(copyWebUi) }

dependencies {
    implementation("androidx.core:core-ktx:1.12.0")
    implementation("androidx.webkit:webkit:1.10.0")
}
